package com.example.lms.controller;

import com.example.lms.entity.User;
import com.example.lms.repository.UserRepository;
import com.example.lms.payload.LoginRequest; // your DTO for login
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository userRepository;

    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request) {
        // validate username/password
        // return JWT token or error
        return "JWT-TOKEN";
    }

    @PostMapping("/signup")
    public User signup(@RequestBody User user) {
        return userRepository.save(user);
    }
}
